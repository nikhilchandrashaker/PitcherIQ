"""150 years of pitching: usage and outcomes by era. Note: 'teams' column is unreliable pre-1960, so we normalise by games_played (team-games)."""
from common import *
m = pd.read_csv(RAW/"mlbpitching.csv").sort_values("year").reset_index(drop=True)
m["ip_per_tg"]   = m.innings_pitched/m.games_played          # innings per team-game
m["cg_rate"]     = m.complete_game/m.games_played*100        # % of team-games completed by the starter
m["so9"]         = m.strikeouts/m.innings_pitched*9
m["bb9"]         = m.walks/m.innings_pitched*9
m["hr9"]         = m.home_runs/m.innings_pitched*9
m["sv_per_100tg"]= m.saves/m.games_played*100
m["pitchers_per_162"] = m.total_pitchers/(m.games_played/162)
m["pitchers_used_per_game"] = m.games_played.where(m.games_played>0)  # placeholder removed below
m["appearances_per_tg"] = (m.games_finished*0+1)  # unused
bins=[1870,1892,1919,1945,1968,1992,2009,2022]
labels=["1871-92 Early","1893-1919 Dead-ball","1920-45 Live-ball","1946-68 Integration/Expansion","1969-92 Five-man/Closer","1993-2009 Steroid/Offense","2010-21 Strikeout/Bullpen"]
m["era"]=pd.cut(m.year,bins=bins,labels=labels)
era = m.groupby("era",observed=True).agg(years=("year","count"),ERA=("ERA","mean"),IP_per_team_game=("ip_per_tg","mean"),
      CG_pct=("cg_rate","mean"),SO9=("so9","mean"),BB9=("bb9","mean"),HR9=("hr9","mean"),SV_per_100=("sv_per_100tg","mean"),
      pitchers_per_162=("pitchers_per_162","mean")).round(2)
era.to_csv(ROOT/"reports/historical_era_summary.csv"); print(era.to_string())
m.drop(columns=["pitchers_used_per_game","appearances_per_tg"]).to_csv(PROC/"historical_derived.csv",index=False)

fig,ax=plt.subplots(2,3,figsize=(15,7.5))
panels=[("ip_per_tg","Innings per team-game (starter+pen)",None),("cg_rate","Complete games, % of team-games",None),
        ("so9","Strikeouts per 9",None),("bb9","Walks per 9",None),("ERA","League ERA",None),("pitchers_per_162","Pitchers used per 162 team-games",None)]
for a,(c,t,_) in zip(ax.ravel(),panels):
    a.plot(m.year,m[c],color="#1f4e79",lw=1.4)
    for b in bins[1:-1]: a.axvline(b+.5,color="grey",ls=":",lw=.7)
    a.set_title(t,fontsize=10,loc="left")
ax[0,0].set_xlim(1871,2021)
fig.suptitle("150 Years of MLB Pitching (dotted lines = era boundaries)",y=1.0,fontsize=13)
fig.tight_layout(); fig.savefig(FIG/"01_historical_trends.png"); plt.close()

# starter->bullpen transition: complete-game rate vs pitchers used
fig,a=plt.subplots(figsize=(6.5,5))
sc=a.scatter(m.cg_rate,m.pitchers_per_162,c=m.year,cmap="viridis",s=22)
plt.colorbar(sc,label="year"); a.set_xlabel("Complete games, % of team-games"); a.set_ylabel("Pitchers used per 162 team-games")
a.set_title("From workhorses to staffs",loc="left"); fig.tight_layout(); fig.savefig(FIG/"02_cg_vs_staff_size.png"); plt.close()
print("corr(CG%, pitchers/162) =", round(m.cg_rate.corr(m.pitchers_per_162),3))
