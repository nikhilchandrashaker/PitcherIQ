"""Audit + build processed tables: seasons (with engineered workload/velocity deltas), TJS-linked pitcher table, WAR (cleaned)."""
from common import *
s = load_seasons()
s = s.sort_values("pa",ascending=False).drop_duplicates(["player_id","year"]).reset_index(drop=True)
print("season rows", len(s), "dup player-year:", s.duplicated(["player_id","year"]).sum())
s["ip_per_game"] = s.ip/s.games
s["kbb"] = s.k_percent - s.bb_percent
s["role"] = np.where(s.ip_per_game>=3, "starter-like", "reliever-like")
s = s.sort_values(["player_id","year"])
# previous *consecutive* season only (2020 absent -> no 2019->2021 pairing)
g = s.groupby("player_id")
for c in ["ip","ff_avg_speed","n","k_percent","bb_percent","woba","xwoba","whiff_percent","games"]:
    s["prev_"+c] = g[c].shift(1); s["prev_year"] = g["year"].shift(1)
    s["d_"+c] = s[c]-s["prev_"+c]
ok = (s.year-s.prev_year==1)
for c in [c for c in s.columns if c.startswith(("prev_","d_")) and c!="prev_year"]:
    s.loc[~ok, c] = np.nan
s["ip_pct_change"] = s.d_ip/s.prev_ip
s["pitches_pct_change"] = s.d_n/s.prev_n
# 2-year chronic baseline (mean of prior two consecutive seasons)
s["prev2_n"] = g["n"].shift(2); s["prev2_year"]=g["year"].shift(2)
s.loc[(s.year-s.prev2_year)!=2,"prev2_n"]=np.nan
s["acwr_pitches"] = s.n/((s.prev_n+s.prev2_n)/2)
s.to_csv(PROC/"pitcher_seasons.csv", index=False)

# TJS linkage
t = pd.read_csv(RAW/"TJS_final_v3.csv")
agg = s.groupby("player_id").agg(
    seasons_obs=("year","nunique"), first_year=("year","min"), last_year=("year","max"),
    age_first=("player_age","min"), ip_mean=("ip","mean"), ip_total=("ip","sum"), games_mean=("games","mean"),
    pitches_total=("n","sum"), k_pct=("k_percent","mean"), bb_pct=("bb_percent","mean"), whiff=("whiff_percent","mean"),
    hardhit=("hard_hit_percent","mean"), gb=("groundballs_percent","mean"), xwoba=("xwoba","mean"),
    ff_speed_mean=("ff_avg_speed","mean"), ipg=("ip_per_game","mean"), hand=("pitch_hand","first")).reset_index()
tj = t.merge(agg, left_on="mlbID", right_on="player_id", how="left")
print("TJS linked:", tj.player_id.notna().sum(), "/", len(tj))
tj.to_csv(PROC/"tjs_master.csv", index=False)

# WAR cleaning
w = pd.read_csv(RAW/"Pitching_WAR.csv", encoding="latin1")
w["bbref_id"] = w.Name.str.split("\\").str[-1]
nm = w.Name.str.split("\\").str[0]
w["hof"] = nm.str.contains("HOF"); w["name_clean"] = nm.str.replace(" HOF","",regex=False).str.replace(r"[*#]","",regex=True).str.strip()
w["debut_year_proxy"] = w.bbref_id.str.extract(r"(\d+)$")[0].astype(float)
w.to_csv(PROC/"war_clean.csv", index=False)

# audit table
rows=[]
for f in sorted(RAW.glob("*.csv")):
    d = pd.read_csv(f, encoding="latin1", low_memory=False)
    rows.append({"file":f.name,"rows":len(d),"cols":d.shape[1],"pct_missing":round(d.isna().mean().mean()*100,1)})
pd.DataFrame(rows).to_csv(ROOT/"reports/data_audit.csv", index=False)
print(pd.DataFrame(rows).to_string())
print(s[["ip","ff_avg_speed","n","acwr_pitches","ip_pct_change"]].describe().T[["count","mean","50%","max"]])
print(tj[["TJS","seasons_obs","ip_mean","ff_speed_mean"]].groupby("TJS").agg(["count","mean"]))
