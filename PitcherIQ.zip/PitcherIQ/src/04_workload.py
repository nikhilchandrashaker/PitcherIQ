"""Workload analysis: (A) season-level workload change vs next-year velocity/performance (all MLB), (B) game-level workload spikes (Japanese-born pitchers, pitch-level Statcast)."""
from common import *
import statsmodels.formula.api as smf
# ---------- A. Season-level ----------
s = pd.read_csv(PROC/"pitcher_seasons.csv")
a = s[(s.pa>=100)&(s.prev_n.notna())&(s.prev_pa if "prev_pa" in s else True)].copy()
a = a[a.prev_ip>=20]                                  # need a meaningful prior workload
a["log_pitch_ratio"]=np.log(a.n/a.prev_n)
a["bucket"]=pd.cut(a.pitches_pct_change,[-1,-.25,-.05,.05,.25,.5,10],labels=["<-25%","-25..-5%","±5%","+5..25%","+25..50%",">+50%"])
bk=a.groupby("bucket",observed=True).agg(n=("name","count"),d_velo=("d_ff_avg_speed","mean"),d_velo_se=("d_ff_avg_speed","sem"),
     d_xwoba=("d_xwoba","mean"),d_kpct=("d_k_percent","mean")).round(3)
print(bk); bk.to_csv(ROOT/"reports/workload_bucket_table.csv")
m = smf.ols("d_ff_avg_speed ~ log_pitch_ratio + player_age + prev_ff_avg_speed + C(year)",data=a.dropna(subset=["d_ff_avg_speed"])).fit(cov_type="HC3")
print(m.summary().tables[1])
m2 = smf.ols("d_xwoba ~ log_pitch_ratio + player_age + prev_xwoba + C(year)",data=a.dropna(subset=["d_xwoba"])).fit(cov_type="HC3")
print("xwOBA: log_pitch_ratio coef", m2.params["log_pitch_ratio"].round(4), "p", m2.pvalues["log_pitch_ratio"].round(4))
pd.DataFrame({"velo_coef":m.params,"velo_p":m.pvalues}).filter(regex="log_pitch|age|prev_ff",axis=0).round(4).to_csv(ROOT/"reports/workload_regression.csv")

fig,ax=plt.subplots(1,3,figsize=(15,4.3))
ax[0].bar(bk.index.astype(str),bk.d_velo,yerr=1.96*bk.d_velo_se,color="#1f4e79",capsize=3); ax[0].axhline(0,color="k",lw=.8)
ax[0].set_title("Next-year change in 4-seam velo by workload change",fontsize=10,loc="left"); ax[0].set_ylabel("mph"); ax[0].tick_params(axis="x",rotation=30)
ax[1].bar(bk.index.astype(str),bk.d_xwoba,color="#c0392b"); ax[1].axhline(0,color="k",lw=.8); ax[1].set_title("Change in xwOBA allowed (+ = worse)",fontsize=10,loc="left"); ax[1].tick_params(axis="x",rotation=30)
ax[2].bar(bk.index.astype(str),bk.n,color="grey"); ax[2].set_title("Pitcher-seasons per bucket",fontsize=10,loc="left"); ax[2].tick_params(axis="x",rotation=30)
fig.tight_layout(); fig.savefig(FIG/"05_workload_change_buckets.png"); plt.close()

# starter vs reliever distributions
fig,ax=plt.subplots(1,2,figsize=(11,4))
for r,c in [("starter-like","#1f4e79"),("reliever-like","#c0392b")]:
    ax[0].hist(s[(s.role==r)].n,bins=40,alpha=.6,color=c,label=r)
ax[0].set_xlabel("Pitches tracked per season"); ax[0].legend(); ax[0].set_title("Annual pitch workload by role (IP/G>=3 = starter-like)",fontsize=10,loc="left")
yr=s[s.pa>=100].groupby(["year","role"]).n.mean().unstack(); yr.plot(ax=ax[1],marker="o",color=["#c0392b","#1f4e79"]); ax[1].set_title("Mean annual pitches (PA>=100)",fontsize=10,loc="left")
fig.tight_layout(); fig.savefig(FIG/"06_role_workload.png"); plt.close()

# ---------- B. Game-level (Japanese-born pitchers) ----------
j = pd.read_csv(RAW/"japanese_mlb_pitching.csv",usecols=["pitcher","player_name_eng","game_pk","game_date","game_year","game_type","pitch_type","release_speed","inning"])
j = j[j.game_type=="R"].copy(); j["game_date"]=pd.to_datetime(j.game_date)
gm = j.groupby(["pitcher","player_name_eng","game_pk","game_date"]).agg(pitches=("pitch_type","size"),first_inn=("inning","min"),last_inn=("inning","max")).reset_index()
fb = j[j.pitch_type.isin(["FF","SI"])].groupby(["pitcher","game_pk"]).release_speed.mean().rename("fb_velo").reset_index()
gm = gm.merge(fb,how="left").sort_values(["pitcher","game_date"])
gm["role"]=np.where(gm.first_inn<=2,"start","relief")
n_games = gm.groupby("pitcher").size(); keep = n_games[n_games>=25].index
gm = gm[gm.pitcher.isin(keep)&(gm.pitches>=5)].copy()
g = gm.groupby("pitcher")
gm["prior3_avg"]=g.pitches.transform(lambda x:x.shift(1).rolling(3,min_periods=3).mean())
gm["days_rest"]=g.game_date.diff().dt.days
gm["spike"]=gm.pitches/gm.prior3_avg-1
gm["next_fb_velo"]=g.fb_velo.shift(-1); gm["next_days"]=g.game_date.shift(-1)
gm["next_rest"]=(gm.next_days-gm.game_date).dt.days
gm["velo_dev_next"]=gm.next_fb_velo-g.fb_velo.transform("mean")
gm["velo_dev_this"]=gm.fb_velo-g.fb_velo.transform("mean")
gm.to_csv(PROC/"game_workload_japanese_pitchers.csv",index=False)
print("pitchers",gm.pitcher.nunique(),"games",len(gm)," start share",(gm.role=="start").mean().round(2))
st=gm[(gm.role=="start")&gm.spike.notna()&gm.velo_dev_this.notna()].copy()
st["spike_bin"]=pd.cut(st.spike,[-1,-.15,.15,.3,5],labels=["drop >15%","±15%","+15..30%","+30%"])
sb=st.groupby("spike_bin",observed=True).agg(n=("pitches","size"),velo_dev_same_game=("velo_dev_this","mean"),velo_dev_next_game=("velo_dev_next","mean")).round(3); print(sb); sb.to_csv(ROOT/"reports/game_spike_table.csv")
mm=smf.ols("velo_dev_next ~ spike + pitches + C(pitcher)",data=st.dropna(subset=["velo_dev_next"])).fit(cov_type="cluster",cov_kwds={"groups":st.dropna(subset=["velo_dev_next"]).pitcher})
print("Next-start velo deviation ~ spike: coef",mm.params["spike"].round(3),"p",mm.pvalues["spike"].round(3),"| per pitch:",mm.params["pitches"].round(4),"p",mm.pvalues["pitches"].round(3))
fig,ax=plt.subplots(1,2,figsize=(12,4.2))
top=gm[gm.role=="start"].groupby("player_name_eng").size().sort_values().tail(1).index[0]
x=gm[(gm.player_name_eng==top)&(gm.role=="start")]
ax[0].plot(x.game_date,x.pitches,"o-",color="#1f4e79"); ax[0].set_title(f"Workload curve: {top} (starts, pitches/game)",fontsize=10,loc="left")
ax[1].scatter(st.pitches,st.velo_dev_this,s=8,alpha=.4,color="#c0392b"); ax[1].set_xlabel("pitches in start"); ax[1].set_ylabel("fastball velo vs own average (mph)")
ax[1].set_title("In-start velocity vs pitch count",fontsize=10,loc="left")
fig.tight_layout(); fig.savefig(FIG/"07_game_workload.png"); plt.close()
print("corr pitches vs same-game velo dev",st.pitches.corr(st.velo_dev_this).round(3))
