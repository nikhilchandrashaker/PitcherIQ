# PitcherIQ — MLB Pitcher Performance, Workload, Injury & Longevity Analytics

Reproduce: `pip install -r requirements.txt && cd src && python run_all.py` (raw CSVs go in `data/raw/`; the two large Japanese Statcast files are not in the zip, so re-add them from your own copy to run `04_workload.py`). Profile any pitcher: `python pitcher_profile.py "Name"`.

Read **reports/REPORT.md** first: findings, limitations and what the data can and cannot support.

| Script | Does |
|---|---|
| 01_data_audit_and_master | Audit, dedupe, IP-notation fix, workload/velocity deltas, TJS link, WAR cleaning |
| 02_historical | 1871–2021 era analysis |
| 03_performance_and_tjs | Drivers of run prevention; TJS vs non-TJS pitch profiles |
| 04_workload | Season workload change; game-level spikes (Japanese-born pitchers) |
| 05_war_archetypes_and_kinematics | Career clusters (top-500 WAR); youth biomechanics |
| 06_injury_model | TJS classification, repeated CV, permutation tests |
| 07_performance_model | Next-season xwOBA / K-BB%, temporal split |
| 08_longevity_survival | Kaplan–Meier + Cox |
