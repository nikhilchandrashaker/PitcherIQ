"""Modern performance drivers + Tommy John pitch-profile comparison (pitcher-level, descriptive)."""
from common import *
from scipy import stats
import seaborn as sns
s = pd.read_csv(PROC/"pitcher_seasons.csv")
q = s[(s.pa>=100)].copy()

# --- What drives run prevention? (xwOBA allowed) ---
feats = ["ff_avg_speed","k_percent","bb_percent","whiff_percent","hard_hit_percent","groundballs_percent","player_age","ip_per_game"]
cor = q[feats+["xwoba"]].corr()["xwoba"].drop("xwoba").sort_values()
print("Correlation with xwOBA allowed (lower=better):\n", cor.round(3))
fig,ax=plt.subplots(1,2,figsize=(12,4.5))
cor.plot.barh(ax=ax[0],color=["#c0392b" if v>0 else "#1f4e79" for v in cor]); ax[0].set_title("Correlation with xwOBA allowed (PA>=100)",loc="left")
yr = q.groupby("year").agg(velo=("ff_avg_speed","mean"),k=("k_percent","mean"),bb=("bb_percent","mean"))
ax[1].plot(yr.index,yr.velo,"o-",color="#1f4e79"); ax[1].set_ylabel("Avg 4-seam velo (mph)",color="#1f4e79")
a2=ax[1].twinx(); a2.plot(yr.index,yr.k,"s--",color="#c0392b"); a2.set_ylabel("K% (avg)",color="#c0392b"); a2.grid(False)
ax[1].set_title("Velocity and strikeouts, 2015-2023 (no 2020 file)",loc="left"); fig.tight_layout(); fig.savefig(FIG/"03_performance_drivers.png"); plt.close()
print(yr.round(2))

# --- TJS comparison ---
t = pd.read_csv(PROC/"tjs_master.csv")
cmp_cols = ["FF_max_velo","FF_release_speed","FF_release_spin_rate","FF_release_extension","FF_release_pos_z","FF_percentage",
            "SL_percentage","CH_percentage","ff max-avg","age_first","seasons_obs","ip_mean","ipg","k_pct","bb_pct","whiff","hardhit","ff_speed_mean"]
rows=[]
for c in cmp_cols:
    a,b = t.loc[t.TJS==1,c].dropna(), t.loc[t.TJS==0,c].dropna()
    if len(a)<8 or len(b)<8: continue
    u = stats.mannwhitneyu(a,b); d=(a.mean()-b.mean())/np.sqrt((a.var()+b.var())/2)
    rows.append({"feature":c,"TJS_mean":a.mean(),"noTJS_mean":b.mean(),"cohens_d":d,"p":u.pvalue,"n_TJS":len(a),"n_ctrl":len(b)})
r = pd.DataFrame(rows).sort_values("p"); r["p_bh"]=stats.false_discovery_control(r.p.values) if hasattr(stats,"false_discovery_control") else np.nan
r.round(4).to_csv(ROOT/"reports/tjs_feature_comparison.csv",index=False); print(r.round(3).to_string())

fig,ax=plt.subplots(1,4,figsize=(15,4))
for a,(c,tt) in zip(ax,[("FF_max_velo","Max 4-seam velo (mph)"),("FF_release_spin_rate","4-seam spin (rpm)"),("seasons_obs","Seasons observed (2015-23)"),("ip_mean","Mean IP / season")]):
    sns.boxplot(data=t,x="TJS",y=c,ax=a,palette=["#9bb7d4","#c0392b"],width=.5); sns.stripplot(data=t,x="TJS",y=c,ax=a,color="k",size=2.5,alpha=.5)
    a.set_title(tt,fontsize=10,loc="left"); a.set_xticklabels(["No TJS","TJS"]); a.set_xlabel("")
fig.tight_layout(); fig.savefig(FIG/"04_tjs_comparison.png"); plt.close()

# exposure confound: seasons observed vs TJS
print(pd.crosstab(pd.cut(t.seasons_obs,[0,2,4,6,9]),t.TJS))
# adjusted logistic: velocity effect controlling for exposure
import statsmodels.api as sm
d = t[["TJS","FF_max_velo","seasons_obs","ipg"]].dropna()
X = sm.add_constant((d[["FF_max_velo","seasons_obs","ipg"]]-d[["FF_max_velo","seasons_obs","ipg"]].mean())/d[["FF_max_velo","seasons_obs","ipg"]].std())
res = sm.Logit(d.TJS,X).fit(disp=0); print(res.summary2().tables[1].round(3))
res.summary2().tables[1].round(4).to_csv(ROOT/"reports/tjs_adjusted_logit.csv")
