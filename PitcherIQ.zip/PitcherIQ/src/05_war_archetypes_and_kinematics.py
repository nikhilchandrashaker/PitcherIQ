from common import *
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn.decomposition import PCA
# ---------- WAR career archetypes ----------
w = pd.read_csv(PROC/"war_clean.csv")
w["peak_share"]=w.WAR7/w.WAR; w["so_per_ip"]=w.SO/w.IP; w["cg_per_ip"]=w.CG/w.IP*100
w["log_ip"]=np.log(w.IP); w["log_war"]=np.log(w.WAR.clip(lower=1))
F=["log_war","log_ip","ERA+","peak_share","WAR/162","so_per_ip"]
X=StandardScaler().fit_transform(w[F].replace([np.inf,-np.inf],np.nan).fillna(w[F].median()))
sil={k:silhouette_score(X,KMeans(k,n_init=20,random_state=0).fit_predict(X)) for k in range(2,8)}; print("silhouette",{k:round(v,3) for k,v in sil.items()})
k=3
base=KMeans(k,n_init=50,random_state=0).fit_predict(X)
rng=np.random.default_rng(0); aris=[]
for _ in range(100):
    idx=rng.choice(len(X),len(X)); lab=KMeans(k,n_init=10,random_state=1).fit(X[idx]).predict(X); aris.append(adjusted_rand_score(base,lab))
print("bootstrap ARI k=3: mean",np.mean(aris).round(3),"min",np.min(aris).round(3))
w["cluster"]=base
prof=w.groupby("cluster")[["WAR","IP","ERA+","WAR7","peak_share","WAR/162","SO","CG","SV"]].mean().round(2); prof["n"]=w.groupby("cluster").size(); prof["hof_share"]=w.groupby("cluster").hof.mean().round(2); print(prof.to_string())
prof.to_csv(ROOT/"reports/war_cluster_profiles.csv")
p=PCA(2).fit_transform(X); fig,a=plt.subplots(figsize=(7,5.5))
for c in range(k):
    a.scatter(p[w.cluster==c,0],p[w.cluster==c,1],s=14,label=f"cluster {c} (n={int((w.cluster==c).sum())})",alpha=.7)
for nm in ["Randy Johnson","Greg Maddux","Clayton Kershaw","Walter Johnson","Sandy Koufax","Pedro Martinez","Justin Verlander"]:
    r=w.index[w.name_clean.str.contains(nm.split()[-1]) & w.name_clean.str.contains(nm.split()[0])]
    for i in r[:1]: a.annotate(nm.split()[-1],p[i],fontsize=8)
a.legend(); a.set_title("Top-500 WAR pitchers: clusters in PCA space",loc="left"); a.set_xlabel("PC1"); a.set_ylabel("PC2"); fig.tight_layout(); fig.savefig(FIG/"08_war_clusters.png"); plt.close()
w.to_csv(PROC/"war_clusters.csv",index=False)

# ---------- Kinematics ----------
b=pd.read_csv(RAW/"baseball_data.csv")
print(b.groupby("ID").size().describe()[["min","mean","max"]].round(1).to_dict(), "age range",b.Age.min(),b.Age.max())
print(b[["Age","Height","Weight","BallSpeed","Pelvis","Trunk"]].corr().round(2)["BallSpeed"])
import statsmodels.formula.api as smf
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error
mm=smf.mixedlm("BallSpeed ~ Pelvis + Trunk + Age + Weight",b,groups=b.ID).fit()
print(mm.summary().tables[1]); pd.DataFrame({"coef":mm.params,"p":mm.pvalues}).round(4).to_csv(ROOT/"reports/kinematics_mixedlm.csv")
Xk=b[["Pelvis","Trunk","Age","Height","Weight"]]; y=b.BallSpeed; gkf=GroupKFold(5)
res={}
for nm,mod in [("mean baseline",None),("Ridge",RidgeCV(alphas=np.logspace(-2,3,20))),("RandomForest",RandomForestRegressor(300,min_samples_leaf=3,random_state=0))]:
    if mod is None: pr=np.full(len(y),np.nan); 
    else: pr=cross_val_predict(mod,(Xk-Xk.mean())/Xk.std(),y,cv=gkf,groups=b.ID)
    if mod is None:
        pr=np.array([y[b.ID!=g].mean() for g in b.ID])
    res[nm]={"R2_grouped_CV":r2_score(y,pr),"MAE":mean_absolute_error(y,pr)}
r=pd.DataFrame(res).T.round(3); print(r); r.to_csv(ROOT/"reports/kinematics_model_cv.csv")
fig,ax=plt.subplots(1,3,figsize=(14,4))
for a,c in zip(ax[:2],["Pelvis","Trunk"]):
    for i,(g,d) in enumerate(b.groupby("ID")): a.scatter(d[c],d.BallSpeed,s=8,alpha=.6)
    a.set_xlabel(c+" (peak angular velocity, deg/s)"); a.set_ylabel("Ball speed"); a.set_title(f"{c} vs ball speed (colour = pitcher)",fontsize=10,loc="left")
sp=b.groupby("ID").agg(age=("Age","first"),speed=("BallSpeed","mean")); ax[2].scatter(sp.age,sp.speed,color="#1f4e79"); ax[2].set_xlabel("Age"); ax[2].set_ylabel("mean ball speed"); ax[2].set_title("Per-pitcher mean ball speed by age",fontsize=10,loc="left")
fig.tight_layout(); fig.savefig(FIG/"09_kinematics.png"); plt.close()
