"""Model 1: Tommy John classification at the PITCHER level (no surgery dates exist, so this is descriptive 'who has TJS', not forecasting).
Two feature sets: (A) pitch-profile only; (B) + exposure/usage. Repeated stratified CV, label-permutation test."""
from common import *
from sklearn.model_selection import RepeatedStratifiedKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.dummy import DummyClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import roc_auc_score, average_precision_score
t=pd.read_csv(PROC/"tjs_master.csv")
pitch=[c for c in t.columns if c.startswith(("FF_","SL_","CH_","CU_","SI_","FC_")) and not c.endswith(("_std","pitch_type"))]+["ff max-avg"]
pitch=[c for c in pitch if t[c].isna().mean()<.5]
expo=["seasons_obs","ipg","ip_mean","age_first","k_pct","bb_pct","whiff","hardhit"]
y=t.TJS.values; print("n",len(t),"pos rate",y.mean().round(3)," pitch feats",len(pitch))
cv=RepeatedStratifiedKFold(n_splits=5,n_repeats=10,random_state=42)
def pipe(m,scale=False): return make_pipeline(SimpleImputer(strategy="median",add_indicator=False),*( [StandardScaler()] if scale else []),m)
models={"Dummy":pipe(DummyClassifier(strategy="prior")),
 "LogReg (L2)":pipe(LogisticRegression(C=.1,max_iter=2000),True),
 "RandomForest":pipe(RandomForestClassifier(500,min_samples_leaf=4,max_features="sqrt",random_state=0,n_jobs=-1)),
 "HistGB":pipe(HistGradientBoostingClassifier(max_depth=2,learning_rate=.05,max_iter=150,min_samples_leaf=8,random_state=0))}
rows=[]; 
for setname,cols in [("A: pitch profile",pitch),("B: pitch + exposure/usage",pitch+expo),("C: exposure only",expo)]:
    X=t[cols]
    for nm,mod in models.items():
        r=cross_validate(mod,X,y,cv=cv,scoring={"auc":"roc_auc","ap":"average_precision","brier":"neg_brier_score"},n_jobs=-1)
        rows.append({"features":setname,"model":nm,"ROC_AUC":r["test_auc"].mean(),"AUC_sd":r["test_auc"].std(),"PR_AUC":r["test_ap"].mean(),"Brier":-r["test_brier"].mean()})
res=pd.DataFrame(rows).round(3); print(res.to_string()); res.to_csv(ROOT/"reports/injury_model_cv.csv",index=False)

# permutation test for best-by-AUC non-dummy model on set B and A
def perm_test(cols,mod,n=200):
    X=t[cols]; rng=np.random.default_rng(1)
    real=cross_validate(mod,X,y,cv=cv,scoring="roc_auc",n_jobs=-1)["test_score"].mean()
    cv2=RepeatedStratifiedKFold(n_splits=5,n_repeats=1,random_state=7)
    null=[cross_validate(mod,X,rng.permutation(y),cv=cv2,scoring="roc_auc",n_jobs=-1)["test_score"].mean() for _ in range(n)]
    return real,(1+np.sum(np.array(null)>=real))/(n+1)
lr=models["LogReg (L2)"]
for nm,cols in [("A pitch-only",pitch),("B pitch+exposure",pitch+expo)]:
    real,p=perm_test(cols,lr); print(f"Permutation test LogReg {nm}: AUC={real:.3f}, p={p:.3f}")
    res.loc[len(res)]=[nm+" perm-test","LogReg",real,np.nan,np.nan,p]
# permutation importance on set B, RF, grouped CV-ish (single holdout repeats)
X=t[pitch+expo]; imps=[]
from sklearn.model_selection import StratifiedKFold
for tr,te in StratifiedKFold(5,shuffle=True,random_state=3).split(X,y):
    m=models["RandomForest"].fit(X.iloc[tr],y[tr]); pi=permutation_importance(m,X.iloc[te],y[te],scoring="roc_auc",n_repeats=20,random_state=0); imps.append(pi.importances_mean)
imp=pd.Series(np.mean(imps,0),index=X.columns).sort_values(ascending=False).head(12); print(imp.round(3))
imp.round(4).to_csv(ROOT/"reports/injury_perm_importance.csv")
fig,ax=plt.subplots(1,2,figsize=(13,4.5))
piv=res[res.features.isin(["A: pitch profile","B: pitch + exposure/usage","C: exposure only"])].pivot(index="model",columns="features",values="ROC_AUC")
piv.plot.bar(ax=ax[0],rot=0,color=["#9bb7d4","#1f4e79","#c0392b"]); ax[0].axhline(.5,color="k",ls="--",lw=.8); ax[0].set_ylim(.4,.8); ax[0].set_title("ROC-AUC, 10x repeated 5-fold CV (0.5 = chance)",fontsize=10,loc="left"); ax[0].legend(fontsize=8)
imp.iloc[::-1].plot.barh(ax=ax[1],color="#1f4e79"); ax[1].set_title("Permutation importance (drop in AUC), RF on set B",fontsize=10,loc="left")
fig.tight_layout(); fig.savefig(FIG/"10_injury_model.png"); plt.close()
