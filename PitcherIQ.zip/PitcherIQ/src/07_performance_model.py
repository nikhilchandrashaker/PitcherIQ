"""Model 2: next-season performance with a strict temporal split. Pairs are consecutive seasons only (no 2020).
Train: features from 2015-17 -> targets 2016-18 | Validation: 2018->2019 | Test: 2021->2022 and 2022->2023."""
from common import *
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.metrics import mean_squared_error, r2_score
s=pd.read_csv(PROC/"pitcher_seasons.csv"); s["log_pitches"]=np.log(s.n)
nxt=s[["player_id","year","xwoba","kbb","pa"]].copy(); nxt["year"]-=1; nxt=nxt.rename(columns={"xwoba":"y_xwoba","kbb":"y_kbb","pa":"pa_next"})
d=s.merge(nxt,on=["player_id","year"]); d=d[(d.pa>=100)&(d.pa_next>=100)].copy()   # target year = year+1
d["target_year"]=d.year+1
base=["player_age","ip_per_game","ip","log_pitches","k_percent","bb_percent","kbb","whiff_percent","hard_hit_percent","groundballs_percent","xwoba","woba","ff_avg_speed","ff_avg_spin"]
work=["d_ip","ip_pct_change","pitches_pct_change","d_ff_avg_speed","d_k_percent","d_xwoba","acwr_pitches"]
d["is_rhp"]=(d.pitch_hand=="R").astype(int); base+=["is_rhp"]
tr=d[d.target_year<=2018]; va=d[d.target_year==2019]; te=d[d.target_year>=2022]
print("pairs: train",len(tr),"val",len(va),"test",len(te))
def mk(name):
    if name=="Ridge": return make_pipeline(SimpleImputer(strategy="median"),StandardScaler(),RidgeCV(alphas=np.logspace(-2,3,20)))
    if name=="RandomForest": return make_pipeline(SimpleImputer(strategy="median"),RandomForestRegressor(400,min_samples_leaf=8,max_features=.4,random_state=0,n_jobs=-1))
    return HistGradientBoostingRegressor(max_depth=3,learning_rate=.04,max_iter=250,min_samples_leaf=25,l2_regularization=1.0,random_state=0)
out=[]
for target,persist in [("y_xwoba","xwoba"),("y_kbb","kbb")]:
    for fs_name,cols in [("base",base),("base+workload",base+work)]:
        for nm in ["Ridge","RandomForest","HistGB"]:
            m=mk(nm).fit(pd.concat([tr,va])[cols] if False else tr[cols],tr[target]); v=np.sqrt(mean_squared_error(va[target],m.predict(va[cols])))
            m=mk(nm).fit(pd.concat([tr,va])[cols],pd.concat([tr,va])[target])   # refit on train+val for test
            p=m.predict(te[cols]); out.append({"target":target,"features":fs_name,"model":nm,"val_RMSE":v,"test_RMSE":np.sqrt(mean_squared_error(te[target],p)),"test_R2":r2_score(te[target],p)})
    for lab,pred in [("Persistence (repeat last yr)",te[persist]),("Train-mean",np.full(len(te),tr[target].mean()))]:
        out.append({"target":target,"features":"-","model":lab,"val_RMSE":np.nan,"test_RMSE":np.sqrt(mean_squared_error(te[target],pred)),"test_R2":r2_score(te[target],pred)})
r=pd.DataFrame(out).round(4); print(r.to_string()); r.to_csv(ROOT/"reports/performance_model_results.csv",index=False)
# bootstrap CI for improvement over persistence (best HistGB/Ridge on xwoba)
best=r[(r.target=="y_xwoba")&(r.features!="-")].sort_values("test_RMSE").iloc[0]; print("best xwoba model:",best.model,best.features)
cols=base+(work if best.features=="base+workload" else []); full=pd.concat([tr,va]); m=mk(best.model).fit(full[cols],full.y_xwoba); p=m.predict(te[cols])
rng=np.random.default_rng(0); gain=[]
for _ in range(1000):
    i=rng.integers(0,len(te),len(te)); e1=np.sqrt(np.mean((te.y_xwoba.values[i]-p[i])**2)); e0=np.sqrt(np.mean((te.y_xwoba.values[i]-te.xwoba.values[i])**2)); gain.append(e0-e1)
print("RMSE gain vs persistence: mean %.4f  95%% CI [%.4f, %.4f]"%(np.mean(gain),*np.percentile(gain,[2.5,97.5])))
fig,ax=plt.subplots(1,2,figsize=(12,4.5))
ax[0].scatter(te.xwoba,te.y_xwoba,s=8,alpha=.4,color="grey",label="last-yr xwOBA"); ax[0].scatter(p,te.y_xwoba,s=8,alpha=.5,color="#1f4e79",label=f"{best.model} prediction")
ax[0].plot([.25,.5],[.25,.5],"k--",lw=.8); ax[0].set_xlabel("predicted / last-year xwOBA"); ax[0].set_ylabel("actual next-year xwOBA"); ax[0].legend(); ax[0].set_title("Test (2022-23): predictions vs actual",fontsize=10,loc="left")
x=r[(r.target=="y_xwoba")]; lab=(x.model+" "+x.features.replace("-","")).str.strip(); ax[1].barh(lab,x.test_RMSE,color=["#c0392b" if "Persist" in l or "mean" in l else "#1f4e79" for l in lab]); ax[1].set_xlim(x.test_RMSE.min()*.95,x.test_RMSE.max()*1.02); ax[1].set_title("Test RMSE, next-season xwOBA (lower = better)",fontsize=10,loc="left")
fig.tight_layout(); fig.savefig(FIG/"11_performance_model.png"); plt.close()
