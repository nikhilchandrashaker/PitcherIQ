from pathlib import Path
import pandas as pd, numpy as np, glob, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = Path(__file__).resolve().parents[1]
RAW, PROC, FIG = ROOT/"data/raw", ROOT/"data/processed", ROOT/"figures"
plt.rcParams.update({"figure.dpi":130,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":.25,"font.size":10})

def ip_to_float(x):
    """Baseball IP notation: 61.1 = 61 1/3 innings, 61.2 = 61 2/3."""
    x = pd.to_numeric(x, errors="coerce")
    whole = np.floor(x); frac = np.round((x-whole)*10)
    return whole + frac/3

def load_seasons():
    fs = sorted(glob.glob(str(RAW/"pitching_data_20*.csv")))
    df = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True)
    df = df.rename(columns={"last_name, first_name":"name","p_game":"games","p_formatted_ip":"ip_raw"})
    df["ip"] = ip_to_float(df["ip_raw"])
    return df
