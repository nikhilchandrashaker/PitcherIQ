import subprocess, sys, pathlib
for f in sorted(pathlib.Path(__file__).parent.glob("0*.py")):
    print("==",f.name); subprocess.run([sys.executable,str(f)],check=True,cwd=f.parent)
