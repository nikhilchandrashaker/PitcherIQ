"""Usage: python pitcher_profile.py "Syndergaard"   -> figures/profile_<name>.png + console summary. Percentiles are vs. all PA>=100 pitcher-seasons in the same year."""
import sys
from common import *
q=sys.argv[1] if len(sys.argv)>1 else "Syndergaard"
s=pd.read_csv(PROC/"pitcher_seasons.csv"); tj=pd.read_csv(PROC/"tjs_master.csv")
x=s[s.name.str.contains(q,case=False,na=False)]
if x.empty: sys.exit("no match")
pid=x.player_id.iloc[0]; x=s[s.player_id==pid].sort_values("year"); nm=x.name.iloc[0]
last=x.iloc[-1]; ref=s[(s.year==last.year)&(s.pa>=100)]
pct=lambda c:int(round((ref[c]<last[c]).mean()*100)) if pd.notna(last[c]) else None
flag=tj[tj.mlbID==pid]; tjs = "not in TJS file" if flag.empty else ("TJS = YES (surgery group)" if flag.TJS.iloc[0]==1 else "TJS = no (comparison group)")
fig,ax=plt.subplots(2,2,figsize=(11,7)); fig.suptitle(f"{nm}  |  {tjs}  |  latest season {int(last.year)}, age {int(last.player_age)}",fontsize=12,x=.02,ha="left")
ax[0,0].plot(x.year,x.ff_avg_speed,"o-",color="#1f4e79"); ax[0,0].set_title("4-seam velocity (mph)",fontsize=10,loc="left")
ax[0,1].bar(x.year,x.n,color="#c0392b"); ax[0,1].set_title("Pitches tracked per season (workload)",fontsize=10,loc="left")
ax[1,0].plot(x.year,x.k_percent-x.bb_percent,"o-",color="#1f4e79"); ax[1,0].set_title("K% - BB%",fontsize=10,loc="left")
items=[("ff_avg_speed","Velocity"),("n","Workload (pitches)"),("kbb","K-BB%"),("whiff_percent","Whiff%"),("xwoba","xwOBA (lower=better)")]
vals=[(l,pct(c)) for c,l in items]; vals=[(l,100-v if "xwOBA" in l else v) for l,v in vals if v is not None]
ax[1,1].barh([l for l,_ in vals],[v for _,v in vals],color="#1f4e79"); ax[1,1].set_xlim(0,100); ax[1,1].set_title(f"Percentile vs {int(last.year)} pitchers",fontsize=10,loc="left")
for i,(l,v) in enumerate(vals): ax[1,1].text(v+1,i,str(v),va="center",fontsize=9)
fig.tight_layout(); out=FIG/f"profile_{q.lower()}.png"; fig.savefig(out); print("saved",out)
print(x[["year","player_age","games","ip","n","ff_avg_speed","k_percent","bb_percent","xwoba"]].round(2).to_string(index=False))
w=pd.read_csv(PROC/"war_clusters.csv"); wm=w[w.name_clean.str.contains(q,case=False)]
if len(wm): print("\nTop-500 WAR:",wm[["name_clean","WAR","IP","ERA+","cluster"]].iloc[0].to_dict())
