"""Model 3: MLB longevity as survival. Cohort = pitchers first seen 2016-2019 (not 2015, to limit left-truncation). Time = # seasons observed (2020 absent from data),
event = no appearance after last_year (<2023); right-censored if still active in 2023. 'Entry' is first appearance in these files, a proxy for debut."""
from common import *
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import multivariate_logrank_test
from sklearn.model_selection import KFold
from lifelines.utils import concordance_index
s=pd.read_csv(PROC/"pitcher_seasons.csv").sort_values(["player_id","year"])
first=s.groupby("player_id").head(1).set_index("player_id"); agg=s.groupby("player_id").agg(first_year=("year","min"),last_year=("year","max"),n_seasons=("year","nunique"))
c=first.join(agg,rsuffix="_a"); c=c[(c.first_year>=2016)&(c.first_year<=2019)].copy()
c["event"]=(c.last_year<2023).astype(int); c["T"]=c.n_seasons
print("cohort",len(c),"events",c.event.sum(),"median seasons observed",c["T"].median())
# 'dropped' means gone from the Savant leaderboard => retired, demoted, or below PA threshold; flag in report
c["velo"]=c.ff_avg_speed.fillna(c.ff_avg_speed.median()); c["ff_missing"]=c.ff_avg_speed.isna().astype(int)
c["starter"]=(c.ip_per_game>=3).astype(int); c["log_ip"]=np.log(c.ip)
for k in ["kbb","hard_hit_percent","whiff_percent","player_age"]: c[k]=c[k].fillna(c[k].median())
cols=["velo","ff_missing","starter","log_ip","kbb","hard_hit_percent","player_age","first_year"]
d=c[cols+["T","event"]].copy(); d["first_year"]=d.first_year-2016
for k in ["velo","kbb","hard_hit_percent","player_age","log_ip"]: d[k]=(d[k]-d[k].mean())/d[k].std()
cph=CoxPHFitter(penalizer=0.05).fit(d,"T","event"); print(cph.summary[["coef","exp(coef)","p"]].round(3))
cph.summary[["coef","exp(coef)","exp(coef) lower 95%","exp(coef) upper 95%","p"]].round(4).to_csv(ROOT/"reports/longevity_cox.csv")
try:
    ph=cph.check_assumptions(d,p_value_threshold=.01,show_plots=False)
except Exception as e: print("PH check:",type(e).__name__)
ci=[]
for tr,te in KFold(5,shuffle=True,random_state=0).split(d):
    m=CoxPHFitter(penalizer=.05).fit(d.iloc[tr],"T","event"); ci.append(concordance_index(d.iloc[te]["T"],-m.predict_partial_hazard(d.iloc[te]),d.iloc[te].event))
print("5-fold concordance: %.3f +- %.3f"%(np.mean(ci),np.std(ci))); pd.Series({"cv_concordance_mean":np.mean(ci),"cv_concordance_sd":np.std(ci)}).round(4).to_csv(ROOT/"reports/longevity_concordance.csv")
c["velo_tercile"]=pd.qcut(c.ff_avg_speed,3,labels=["slow","mid","fast"]); c["rolegrp"]=np.where(c.starter==1,"starter-like","reliever-like")
fig,ax=plt.subplots(1,2,figsize=(12,4.5))
for a,col,ttl in [(ax[0],"velo_tercile","by 4-seam velocity tercile"),(ax[1],"rolegrp","by role")]:
    sub=c.dropna(subset=[col])
    for g,x in sub.groupby(col,observed=True):
        KaplanMeierFitter().fit(x["T"],x.event,label=f"{g} (n={len(x)})").plot_survival_function(ax=a,ci_show=True)
    lr=multivariate_logrank_test(sub["T"],sub[col].astype(str),sub.event); a.set_title(f"Still pitching, {ttl} (log-rank p={lr.p_value:.3f})",fontsize=10,loc="left"); a.set_xlabel("seasons observed since first appearance"); a.set_ylim(0,1.02)
    print(ttl,"log-rank p",round(lr.p_value,4))
fig.tight_layout(); fig.savefig(FIG/"12_longevity_km.png"); plt.close()
c.reset_index().to_csv(PROC/"longevity_cohort.csv",index=False)
